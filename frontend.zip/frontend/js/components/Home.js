export function Home() {
  return `
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Card Title</h5>
          <p class="card-text">This is a simple card component built with Bootstrap.</p>
        </div>
      </div>
    `;
}
